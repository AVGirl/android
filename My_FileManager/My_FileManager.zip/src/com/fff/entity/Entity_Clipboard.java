package com.fff.entity;

public class Entity_Clipboard {
	//String 

}
