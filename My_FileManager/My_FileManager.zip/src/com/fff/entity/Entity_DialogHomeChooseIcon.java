package com.fff.entity;

public class Entity_DialogHomeChooseIcon {
	int id;
	public Entity_DialogHomeChooseIcon(int id) {
		this.id = id;
	}
}
