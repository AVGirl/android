package com.fff.entity;

public class ClassIntFiled {
public String names[];
public ClassIntFiled(String[] name, int[] values) {
	this.names = name;
	this.values = values;
}
public int values[];
}
