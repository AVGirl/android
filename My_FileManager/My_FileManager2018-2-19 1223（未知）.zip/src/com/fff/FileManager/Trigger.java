package com.fff.FileManager;

import android.os.Handler;
import android.os.Message;

public class Trigger  extends Handler{
	static Handler handler ;
static void  init(Handler mhandler){
		handler=mhandler;
		
		
	}


@Override
public void handleMessage(Message msg) {

}


	

}
